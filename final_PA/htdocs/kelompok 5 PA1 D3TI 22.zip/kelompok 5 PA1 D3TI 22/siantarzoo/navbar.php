<nav class="navbar navbar-expand-lg navbar-dark warna1"> 
    <div class="container">
        <button class="navbar-toggler" type="button" data-bs-toggle="collapse" 
        data-bs-target="#navbarTogglerDemo02" aria-controls="navbarTogglerDemo02" 
        aria-expanded="false" aria-label="Toggle navigation"> 
            <span class="navbar-toggler-icon"></span>
        </button>
        <div class="collapse navbar-collapse" id="navbarTogglerDemo02">
            <ul class="navbar-nav me-auto mb-2 mb-lg-0">
                <li class="nav-item me-3">
                    <a class="nav-link" href="index.php">Beranda</a> 
                </li>
                <li class="nav-item me-3"> 
                    <a class="nav-link" href="about-us.php">Tentang Kami</a> 
                </li>
                <li class="nav-item me-3"> 
                    <a class="nav-link" href="service.php">Kategori Hewan dan Layanan</a>
                </li>
            </ul>
            <ul class="navbar-nav ms-auto mb-2 mb-lg-0">
                <li class="nav-item me-3">
                    <a class="nav-link" href="adminpanel/login.php">Admin Login</a>
                </li>
            </ul>
        </div>
    </div>
</nav>