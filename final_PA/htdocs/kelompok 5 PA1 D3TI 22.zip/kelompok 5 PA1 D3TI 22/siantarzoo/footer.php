<div class="container-fluid py-5 content-subscribe text-light">
    <div class="container">
        <h5 class="text-center mb-4">Temukan kami</h5>
        <div class="row justify-content-center">
            <div class="col-sm-1 d-flex justify-content-center mb-2">
                <a href="https://web.facebook.com/tamanhewansiantar/?_rdc=1&_rdr">
                    <i class="fab fa-facebook fs-4"></i> </a>
            </div>
            <div class="col-sm-1 d-flex justify-content-center mb-2">
                <a href="https://www.instagram.com/siantar_zoo/?hl=id">
                    <i class="fab fa-instagram fs-4"></i></a>
            </div>
            <div class="col-sm-1 d-flex justify-content-center">
                <a href="https://api.whatsapp.com/send?phone=628116717172">
                    <i class="fab fa-whatsapp fs-4"></i></a>
            </div>
        </div>
    </div>
</div>
<div class="container-fluid py-3 bg-dark text-light">
    <div class="container d-flex justify-content-between">
        <label>&copy; Siantar Zoo</label>
        <label>Dibuat Oleh Kelompok 5 PA1 D3TI 22</label>
    </div>
</div>